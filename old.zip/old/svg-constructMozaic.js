// Change source and format when Spreadsheet ok
function getData(sheetId, feuille) {
    $.ajax({
        type: 'GET',
        url: 'https://projectionpad.philharmoniedeparis.fr/api/listesFiltrees/getSheet/' + sheetId + '?range=' + feuille + '&majorDimension=ROWS',
        success: function(results) {
            displayMos(results, "idMozaic");
            sliderDebordement()

        },
        error: function(e) {
            console.log('ERROR: ', e);
        }
    });
}
$(document).ready(function() {
    const sheetId = document.getElementById("sheetid").value
    const feuille = document.getElementById("feuille").value

    getData(sheetId, feuille)
})


/* ********** Create and populate thumbnails ********** */
function displayMos(data, idMozaic) {
    // On vérifie si le navigateur prend en charge la fonctionnalité
    if ("content" in document.createElement("template")) {

        var container = $(`#${idMozaic}`);


        var ul = document.createElement('ul')
        ul.setAttribute("class", "mozaik-liste")
        ul.setAttribute("id", "mozaikContainer")

        container.append(ul)

        $("")

        var template = document.querySelector(`#mozaik-template`);


        data.forEach(e => {

            if (e.Year != "") {
                var clone = document.importNode(template.content, true);
                let tagRegex = /<i>|<\/i>|<em>|<\/em>/gm
                let regexHref = /<a.+href='|'.+|<a.+href="|".+/gm

                let titre = clone.querySelector("#mos-titre")
                let sous_titre = clone.querySelector("#mos-sous_titre")
                let description = clone.querySelector("#mos-description")
                let cat = clone.querySelector("#mos-cat")
                let sous_cat = clone.querySelector("#mos-sous_cat")
                let link = clone.querySelector("#mos-link")
                let img = clone.querySelector("#mos-img")
                let lieu = clone.querySelector("#mos-lieu")
                let date = clone.querySelector("#mos-date")
                let button = clone.querySelector("#mos-button")

                if (e.date.length && (date != null)) {
                    date.textContent = e.date
                    date.removeAttribute('id')
                }
                if (e.lieu && (lieu != null)) {
                    lieu.textContent = e.lieu
                    lieu.removeAttribute('id')
                }
                if (e.titre && (titre != null)) {
                    titre.textContent = e.titre.replace(/&nbsp;/gm, " ").replace(tagRegex, "")
                    titre.removeAttribute('id')
                }
                if (e.sous_titre && (sous_titre != null)) {
                    sous_titre.textContent = e.sous_titre
                    sous_titre.removeAttribute('id')
                }
                if (e.description && (description != null)) {
                    description.textContent = e.description
                    description.removeAttribute('id')
                }
                if (e.cat && (cat != null)) {
                    cat.textContent = e.cat
                    cat.removeAttribute('id')
                }
                if (e.sous_cat && (sous_cat != null)) {
                    sous_cat.textContent = e.sous_cat
                    sous_cat.removeAttribute('id')
                }
                if (e.img && (img != null)) {
                    img.setAttribute("src", e.img)
                    img.setAttribute("data-src", e.img)
                    img.setAttribute("alt", e.img_alt)
                    img.removeAttribute('id')
                }
                if (e.link && (link != null)) {
                    link.setAttribute("href", e.link.replace(regexHref, ''))
                    link.setAttribute("title", e.link_title)
                    link.removeAttribute('id')

                }

                ul.appendChild(clone);
            }
        })
    }
    createFilter("idMozaic")
}