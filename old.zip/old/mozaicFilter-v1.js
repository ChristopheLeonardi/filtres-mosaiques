/* Génération des filtres des mosaïques Christophe 20/05/2022 */

/* ----------------------------------------------------------------
1. Mise en place 

a) Ciblage de la mosaïque : 
Dans le code html renseigner une id sur div.mozaik-wrap pour spécifier sur quelle mosaïque les filtres seront générés.

b) Paramétrage des filtres :
Ajouter l'attribut data-name="[nom du champ]" afin de créer la catégorie de filtre. Les filtres sont programmés pour 3 types d'informations : les filtres par valeurs, par ordre alphabétiques et par date.

c) dans l'encart appeler le script avec la ligne :
$(document).ready(function() { createFilter("[idMozaic]") })
---------------------------------------------------------------- */

/* ----------------------------------------------------------------
2. Description du fonctionnement

a) La fonction createFilter(id) récupère les données des attributs data-name, créé le container pour les filtres et execute les fonctions de création des filtres

b) La fonction createSelectFilter(dataType, dataListName) créé le DOM de la balise select générale.

c) Les fonction option[name] peuplent les balises options avec les données pertinentes des différents filtres

d) Les fonctions filter[name] régissent les comportements des filtres 
---------------------------------------------------------------- */
/* TODO : gestion des sous-catégories*/
/* TODO : masquer les options sans sortie (0 résultat) */
/* TODO : augmenter souplesse de data-name et générer des filtres en fonctions des noms renseignés*/
/* TODO : fusionner date et titre sous un filtre tri */
$(document).ready(function() {

    createFilter("moz1")

})
const createFilter = (idMozaic) => {

    const titres = $(`#${idMozaic} *[data-name='Titre']`)
    const dates = $(`#${idMozaic} *[data-name='Date']`)
    const lieux = $(`#${idMozaic} *[data-name='Lieu']`)
    const categories = $(`#${idMozaic} *[data-name='Catégorie']`)

    /* Create filter container */

    const filterContainer = document.createElement('div')
    filterContainer.setAttribute("class", "filterContainer Slider fixed-elt-scroll only-scrollup")
    filterContainer.style.justifyContent = "flex-start"


    const sectionName = document.createElement("h3")
    sectionName.textContent = "Filtres"
    filterContainer.appendChild(sectionName)

    if (categories.length) {
        filterContainer.appendChild(createSelectFilter(optionValue, categories))
    }
    if (lieux.length) {
        filterContainer.appendChild(createSelectFilter(optionValue, lieux))
    }
    if (dates.length) {
        filterContainer.appendChild(createSelectFilter(optionsDate, dates))
    }
    if (titres.length) {
        filterContainer.appendChild(createSelectFilter(optionsAlpha, titres))
    }

    let resetButtonContainer = document.createElement("div")
    resetButtonContainer.setAttribute("class", "Slider-item")

    let resetButton = document.createElement("button")
    resetButton.setAttribute("class", "btn btn-default")
    resetButton.setAttribute("id", "resetFilter")
    resetButton.textContent = "Réinitialiser les filtres"
    resetButtonContainer.appendChild(resetButton)

    filterContainer.appendChild(resetButtonContainer)

    $(`#${idMozaic}`).prepend(filterContainer)

    // Initiate filters
    const target = $(`#${idMozaic} .mozaik-item`)

    filterValue(target, "Catégorie")
    filterValue(target, "Lieu")
    filterDate(target, "Date")
    filterAlpha(target, "Titre")

    resetFilter(idMozaic)
}

const createSelectFilter = (dataType, dataListName) => {

    // Create select container
    let selectContainer = document.createElement("div")
    selectContainer.setAttribute("class", "Slider-item")

    // Create Label
    let selectLabel = document.createElement("label")
    selectLabel.setAttribute("for", $(dataListName).attr("data-name"))
    selectLabel.textContent = `${$(dataListName).attr("data-name")} : `

    // Create select box
    var selectBox = document.createElement("select")
    selectBox.setAttribute("name", $(dataListName).attr("data-name"))
    selectBox.setAttribute("id", $(dataListName).attr("data-name"))

    // Create default option box
    var selectOption = document.createElement("option")
    selectOption.textContent = "Aucun filtre"
    selectOption.value = "none"
    selectBox.appendChild(selectOption)

    dataType(dataListName, selectBox)

    selectContainer.appendChild(selectLabel)
    selectContainer.appendChild(selectBox)

    return selectContainer

}


const optionValue = (dataListName, selectBox) => {

    // Remove duplicate
    arrayDataList = Array.from(dataListName)
    arrayDataList = arrayDataList.filter((value, index, self) =>
        index === self.findIndex((t) => (
            $(t).text() === $(value).text()
        ))
    )

    arrayDataList.forEach(dataName => {

        // Create option box
        let selectOption = document.createElement("option")
        selectOption.textContent = $(dataName).text()
        selectOption.value = $(dataName).text().replace(/\s/g, "")
        selectBox.appendChild(selectOption)

        // Set Attribute in item 
        let optionName = `data-${$(dataName).attr("data-name")}`
        dataName.setAttribute(optionName, $(dataName).text().replace(/\s/g, ""))

    })

    Array.from(dataListName).forEach(dataName => {

        // Set Attribute in .mozaik-item for filter
        let optionName = `data-${$(dataName).attr("data-name")}`
        $(dataName).parents(".mozaik-item").attr(optionName, $(dataName).text().replace(/\s/g, ""))

    })


}

const optionsAlpha = (dataListName, selectBox) => {

    // Create option box
    let selectAlpha = document.createElement("option")
    selectAlpha.textContent = "A à Z"
    selectAlpha.value = "alpha"
    selectBox.appendChild(selectAlpha)

    // Create option box
    let selectInv = document.createElement("option")
    selectInv.textContent = "Z à A"
    selectInv.value = "inverse"
    selectBox.appendChild(selectInv)

    // Set Attribute in .mozaik-item for filter
    Array.from(dataListName).forEach(dataName => {

        let titreEvent = $(dataName).text().toLowerCase()
        let optionName = `data-${$(dataName).attr("data-name")}`
        $(dataName).parents(".mozaik-item").attr(optionName, titreEvent)

    })

}

// Set option filter and 
const optionsDate = (dataListName, selectBox) => {

    // Create option box
    let selectNewer = document.createElement("option")
    selectNewer.textContent = "Les plus récents"
    selectNewer.value = "newer"
    selectBox.appendChild(selectNewer)

    // Create option box
    let selectOlder = document.createElement("option")
    selectOlder.textContent = "Les plus ancients"
    selectOlder.value = "older"
    selectBox.appendChild(selectOlder)

    // Set Attribute in .mozaik-item for filter
    Array.from(dataListName).forEach(dataName => {

        let dateEvent = convertDate($(dataName).text())
        let optionName = `data-${$(dataName).attr("data-name")}`
        $(dataName).parents(".mozaik-item").attr(optionName, dateEvent)

    })

}

// Convert string date into time stamp
const convertDate = (dateString) => {
    const month = ["janvier", "fevrier", "mars", "avril", "mai", "juin", "juillet", "aout", "septembre", "octobre", "novembre", "decembre"]
    var sanitizeDate = dateString.toLowerCase().replace(/é|è|ê/gm, "e").replace(/û/gm, "u").replace(/\s+/gm, "/")

    month.forEach((m, i) => {
        sanitizeDate = sanitizeDate.replace(m, i)
    })
    var partDate = sanitizeDate.split("/");
    let dateEvent = new Date(parseInt(partDate[2], 10), parseInt(partDate[1], 10), parseInt(partDate[0], 10))
    return Date.parse(dateEvent)
        /* TODO : add condition if only year + roman century */

}

// Filter .mozaik-item by value
const filterValue = (target, valueType) => {

    $(`select[name="${valueType}"]`).change(function() {
        var value = $(this).val()
        Array.from(target).forEach((e, i) => {
            //console.log(value, $(e).attr(`data-${valueType}`))
            let optionValue = $(e).attr(`data-${valueType}`)
            if (value == "none") {

                e.removeAttribute('hidden');

            } else if (optionValue != value) {
                e.setAttribute('hidden', true)

            } else if (optionValue == value) {
                console.log($(e).attr('hidden'))
                if ($(e).attr('hidden') == 'hidden') {
                    return
                }
                e.removeAttribute('hidden');
            }
        })

    })
}

// Filter .mozaik-item by date asc, desc
const filterDate = (target, valueType) => {

    var arrayTarget = Array.from(target)

    // Tri les items en fonction de la valeurs du timestamp
    arrayTarget.sort(function compare(a, b) {
        return $(a).attr(`data-${valueType}`) - $(b).attr(`data-${valueType}`)
    })

    $(`select[name="${valueType}"]`).change(function() {

        var value = $(this).val()

        arrayTarget.forEach((e, i) => {

            switch (value) {
                case "older":
                    e.style.order = i.toString()
                    break
                case "newer":
                    let reverseOrder = arrayTarget.length - i
                    e.style.order = reverseOrder.toString()
                    break
                default:
                    e.style.order = "unset"
                    break
            }

        })

    })
}

// Filter .mozaik-item by alphabetic order
const filterAlpha = (target, valueType) => {
    var arrayTarget = Array.from(target)

    // Tri les items en fonction de la valeurs du timestamp
    arrayTarget.sort(function compare(a, b) {
        if ($(a).attr(`data-${valueType}`) < $(b).attr(`data-${valueType}`)) { return -1; }
        if ($(b).attr(`data-${valueType}`) > $(b).attr(`data-${valueType}`)) { return 1; }
        return 0;
    })

    $(`select[name="${valueType}"]`).change(function() {

        var value = $(this).val()

        arrayTarget.forEach((e, i) => {
            switch (value) {
                case "alpha":
                    e.style.order = i.toString()
                    break
                case "inverse":
                    let reverseOrder = arrayTarget.length - i
                    e.style.order = reverseOrder.toString()
                    break
                default:
                    e.style.order = "unset"
                    break
            }

        })

    })
}

// Reset filter Button
const resetFilter = (idMozaic) => {
    var button = $(`#${idMozaic} #resetFilter`)
    button.click(() => {
        Array.from($(`#${idMozaic} select`)).forEach(e => {
            $(e).val("none").change()
        })
    })
}