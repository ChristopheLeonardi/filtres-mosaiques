const selectPosition = () => {
    // Hack for overflow x/y not working (conflit avec le slider)
    var menuPosition = $("#filterContainer").offset()
    console.log(menuPosition)
    var scroll = 0
    var filters = $('.select-selected')
    Array.from(filters).forEach(filter => {

        $(filter).next().css('top', `${menuPosition.top + 115 - scroll}px`)
        let filterWidth = $(filter).outerWidth()
        let filterPosition = $(filter).offset()
        $(filter).next().css('position', 'fixed')
        $(filter).next().css('width', `${filterWidth + 20}px`)
        $(filter).next().css('left', `${filterPosition.left - 10}px`)
    })

    $(document).scroll(() => {
        scroll = $(window).scrollTop();
        Array.from(filters).forEach(filter => {
            $(filter).next().css('top', `${menuPosition.top + 115 - scroll}px`)

        })

    })
    var filterContainerWidth = $(".filterContainer").outerWidth()
    $('.scroll-slider-button.scroll-left-slider-button').click(() => {

        var sliderItems = $('.select-selected')
        console.log(filterContainerWidth)
        Array.from(sliderItems).forEach(sliderItem => {

            let filterPosition = $(sliderItem).offset()
            var newPosition = filterPosition.left + 180
                //console.log(newPosition)
            $(sliderItem).next().css('left', `${newPosition}px`)

        })
    })
    $('.scroll-slider-button.scroll-right-slider-button').click(() => {

        var sliderItems = $('.select-selected')
        console.log(filterContainerWidth)

        Array.from(sliderItems).forEach(sliderItem => {

            let filterPosition = $(sliderItem).offset()
            var newPosition = filterPosition.left - 180
                //  console.log(newPosition)

            $(sliderItem).next().css('left', `${newPosition}px`)

        })

    })


    // END Hack for overflow x/y not working (conflit avec le slider)
}