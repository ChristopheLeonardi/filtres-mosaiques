const uiMozaicFilter = () => {
    var filterElements = $(".Slider-item")
    var containerWidth = filterElements.length * 150
    $("#filterContainer .filterContainer").width(`${containerWidth}px`)
}