/* Génération des filtres des mosaïques Christophe 20/05/2022 */

/* ----------------------------------------------------------------
1. Mise en place 

a) Ciblage de la mosaïque : 
Dans le code html renseigner une id sur div.mozaik-wrap pour spécifier sur quelle mosaïque les filtres seront générés.

b) Paramétrage des filtres :
Ajouter l'attribut data-name="[nom du champ]" afin de créer la catégorie de filtre. Les filtres sont programmés pour 3 types d'informations : les filtres par valeurs, par ordre alphabétiques et par date.

c) dans l'encart appeler le script avec la ligne :
$(document).ready(function() { createFilter("[idMozaic]") })
---------------------------------------------------------------- */

/* ----------------------------------------------------------------
2. Description du fonctionnement

a) La fonction createFilter(id) récupère les données des attributs data-name, créé le container pour les filtres et execute les fonctions de création des filtres

b) La fonction createSelectFilter(createOptionsValues, dataListName) créé le DOM de la balise select générale.

c) Les fonction option[name] peuplent les balises options avec les données pertinentes des différents filtres

d) Les fonctions filter[name] régissent les comportements des filtres 
---------------------------------------------------------------- */
/* TODO : gestion des sous-catégories*/
/* TODO : augmenter souplesse de data-name et générer des filtres en fonctions des noms renseignés*/
$(document).ready(function() {

    createFilter("idMozaic")

})

const createFilter = (idMozaic) => {

    const titres = $(`#${idMozaic} *[data-name='Titre']`)
    const dates = $(`#${idMozaic} *[data-name='Date']`)
    const lieux = $(`#${idMozaic} *[data-name='Lieu']`)
    const categories = $(`#${idMozaic} *[data-name='Catégorie']`)

    /* Create filter container */

    const filterContainer = document.createElement('div')
    filterContainer.setAttribute("class", "filterContainer Slider fixed-elt-scroll only-scrollup")
    filterContainer.style.justifyContent = "flex-start"


    const sectionName = document.createElement("h3")
    sectionName.textContent = "Filtres"
    filterContainer.appendChild(sectionName)

    if (categories.length) {
        filterContainer.appendChild(createSelectFilter(optionValue, categories))
        setDataAttributes(categories)
    }
    if (lieux.length) {
        filterContainer.appendChild(createSelectFilter(optionValue, lieux))
        setDataAttributes(lieux)
    }
    if ((titres.length) || (dates.length)) {
        filterContainer.appendChild(createSelectFilter(optionTri, titres, dates))
        if (titres.length) {
            setDataAttributes(titres, "alpha")
        }
        if (dates.length) {
            setDataAttributes(dates, "date")
        }
    }

    createResetButton(filterContainer)

    $("#idMozaic").prepend(filterContainer)

    // Initiate filters
    const target = $(`#${idMozaic} .mozaik-item`)

    filterValue(idMozaic, target, "Catégorie", "Lieu")
    filterAlphaDate(target)


    resetFilter(idMozaic)

}


const createSelectFilter = (createOptionsValues, dataListName, dataOptionName = null) => {

    var value = $(dataListName).attr("data-name")
    if (dataOptionName != null) {
        value = "Tri"
    }

    // Create select container
    let selectContainer = document.createElement("div")
    selectContainer.setAttribute("class", "Slider-item")

    // Create Label
    let selectLabel = document.createElement("label")
    selectLabel.setAttribute("for", value)
    selectLabel.textContent = `${value} : `

    // Create select box
    var selectBox = document.createElement("select")
    selectBox.setAttribute("name", value)
    selectBox.setAttribute("id", value)

    // Create default option box
    createOption("Aucun filtre", "none", selectBox)

    createOptionsValues(dataListName, selectBox)

    selectContainer.appendChild(selectLabel)
    selectContainer.appendChild(selectBox)

    return selectContainer

}

const createOption = (textContent, value, selectBox) => {
    // Create option box
    let option = document.createElement("option")
    option.textContent = textContent
    option.value = value
    selectBox.appendChild(option)
}

const optionTri = (dataListName = null, selectBox) => {

    // Create option box
    createOption("A à Z", "alpha", selectBox)
    createOption("Z à A", "inverse", selectBox)
    createOption("Les plus récents", "newer", selectBox)
    createOption("Les plus ancients", "older", selectBox)

}

const optionValue = (dataListName, selectBox) => {

    // Remove duplicate
    arrayDataList = Array.from(dataListName)
    arrayDataList = arrayDataList.filter((value, index, self) =>
        index === self.findIndex((t) => (
            $(t).text() === $(value).text()
        ))
    )

    arrayDataList.forEach(dataName => {

        // Create option box
        let textValue = $(dataName).text()
        let value = $(dataName).text().replace(/\s/g, "")
        createOption(textValue, value, selectBox)

    })
}


const setDataAttributes = (dataListName, name = null) => {

    // Set Attribute in .mozaik-item for filter
    Array.from(dataListName).forEach(dataName => {
        switch (name) {
            case "date":
                value = convertDate($(dataName).text())
                break
            case "alpha":
                value = $(dataName).text().toLowerCase().replace(/\s+/gm, "")
                break
            default:
                value = $(dataName).text().replace(/\s+/gm, "")
                break
        }

        let optionName = `data-${$(dataName).attr("data-name")}`
        $(dataName).parents(".mozaik-item").attr(optionName, value)

    })
}

// Filter .mozaik-item by value
const filterValue = (idMozaic, target, valueType1, valueType2 = null, valueType3 = null) => {

    var arrayIsVisible = Array(target.length)
    for (var i = 0; i < arrayIsVisible.length; i++) {
        arrayIsVisible[i] = {}
        arrayIsVisible[i][valueType1] = true
        if (valueType2) {
            arrayIsVisible[i][valueType2] = true
        }
        if (valueType3) {
            arrayIsVisible[i][valueType3] = true
        }
    }
    arrayIsVisible.forEach((array, i) => {

        Object.keys(array).forEach((valueType) => {

            $(`select[name="${valueType}"]`).change(function() {

                var value = $(this).val()

                let optionValueSelect = $(target[i]).attr(`data-${valueType}`)

                if ((value == "none") || (optionValueSelect == value)) {
                    array[valueType] = true

                } else {
                    array[valueType] = false

                }
                Array.from(target).forEach((item, i) => {
                    if (arrayIsVisible[i][valueType1] == true && arrayIsVisible[i][valueType2] == true) {
                        item.removeAttribute('hidden')
                        isAllVisible = true
                    } else if (arrayIsVisible[i][valueType1] == false || arrayIsVisible[i][valueType2] == false) {
                        item.setAttribute('hidden', true)
                        isAllVisible = false
                    }
                })
                allItemHidden(idMozaic)

            })



        })

    })
}
const allItemHidden = (idMozaic) => {
    var isAllHidden = $(`#${idMozaic} .mozaik-item[hidden="true"]`)
    var allItem = $(`#${idMozaic} .mozaik-item`)
    var isAlert = $(`#${idMozaic} .alertMessage`).length

    if ((isAllHidden.length == allItem.length) && (isAlert == 0)) {
        let alertContainer = document.createElement('div')
        alertContainer.setAttribute("class", "alertMessage")

        let alertMessage = document.createElement('p')
        alertMessage.textContent = "Votre sélection de filtre n'a donné aucun résultat"
        alertContainer.appendChild(alertMessage)

        createResetButton(alertContainer)

        $(`#${idMozaic} .mozaik-liste`).prepend(alertContainer)
        resetFilter(idMozaic)

    } else if ((isAllHidden.length != allItem.length) && (isAlert != 0)) {
        $(`#${idMozaic} .mozaik-liste .alertMessage`).remove()
    }
}

// Filter .mozaik-item by date asc, desc
const filterAlphaDate = (target) => {

    var arrayTarget = Array.from(target)

    $(`select[name="Tri"]`).change(function() {

        var value = $(this).val()
        if ((value == "older") || (value == "newer")) {
            // Tri les items en fonction de la valeurs du timestamp
            arrayTarget = arrayTarget.sort(function compare(a, b) {

                return $(a).attr(`data-Date`) - $(b).attr(`data-Date`)
            })

        } else {
            // Tri les items en fonction de la valeurs du timestamp
            arrayTarget = arrayTarget.sort(function compare(a, b) {
                if ($(a).attr(`data-Titre`) < $(b).attr(`data-Titre`)) { return -1 }
                if ($(b).attr(`data-Titre`) > $(b).attr(`data-Titre`)) { return 1 }
                return 0;
            })
        }

        arrayTarget.forEach((e, i) => {

            switch (value) {
                case "older":
                case "alpha":
                    e.style.order = i.toString()
                    break
                case "newer":
                case "inverse":
                    let reverseOrder = arrayTarget.length - i
                    e.style.order = reverseOrder.toString()
                    break
                default:
                    e.style.order = "unset"
                    break
            }

        })

    })
}

// Convert string date into time stamp
const convertDate = (dateString) => {
    const month = ["janvier", "fevrier", "mars", "avril", "mai", "juin", "juillet", "aout", "septembre", "octobre", "novembre", "decembre"]
    var sanitizeDate = dateString.toLowerCase().replace(/é|è|ê/gm, "e").replace(/û/gm, "u").replace(/\s+/gm, "/")

    month.forEach((m, i) => {
        sanitizeDate = sanitizeDate.replace(m, i)
    })
    var partDate = sanitizeDate.split("/");
    let dateEvent = new Date(parseInt(partDate[2], 10), parseInt(partDate[1], 10), parseInt(partDate[0], 10))
    return Date.parse(dateEvent)
        /* TODO : add condition if only year + roman century */

}

// Create DOM reset button
const createResetButton = (container) => {
    let resetButtonContainer = document.createElement("div")
    resetButtonContainer.setAttribute("class", "Slider-item")

    let resetButton = document.createElement("button")
    resetButton.setAttribute("class", "btn btn-default resetFilter")
    resetButton.textContent = "Réinitialiser les filtres"
    resetButtonContainer.appendChild(resetButton)

    container.appendChild(resetButtonContainer)
}

// Reset filter Button
const resetFilter = (idMozaic) => {
    var button = $(`.resetFilter`)
    button.click(() => {
        Array.from($(`#${idMozaic} select`)).forEach(e => {
            $(e).val("none").change()
        })
    })
}